package me.lcgui.game;

public class IllegalMoveException extends Exception {}
