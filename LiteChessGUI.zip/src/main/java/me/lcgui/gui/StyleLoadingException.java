package me.lcgui.gui;

public class StyleLoadingException extends Exception {
    public StyleLoadingException() {
        super();
    }

    public StyleLoadingException(String msg) {
        super(msg);
    }

    public StyleLoadingException(Throwable cause) {
        super(cause);
    }
}
